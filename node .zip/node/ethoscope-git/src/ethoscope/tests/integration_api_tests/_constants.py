VIDEO = "../static_files/videos/arena_10x2_sortTubes.mp4"
DRAW_FRAMES = True