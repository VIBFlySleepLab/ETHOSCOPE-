__author__ = 'quentin'

import unittest

class TestExple(unittest.TestCase):

    def test_exple(self):

        ans = 1
        ref = 1
        self.assertEqual(ans, ref)
