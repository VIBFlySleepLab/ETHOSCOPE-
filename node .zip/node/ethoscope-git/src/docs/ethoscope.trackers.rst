ethoscope.trackers package
==========================


Module contents
---------------

.. automodule:: ethoscope.trackers
    :members:
    :undoc-members:
    :show-inheritance:

ethoscope.trackers.trackers module
----------------------------------

.. automodule:: ethoscope.trackers.trackers
    :members:
    :undoc-members:
    :show-inheritance:


ethoscope.trackers.single_roi_tracker module
--------------------------------------------

.. automodule:: ethoscope.trackers.single_roi_tracker
    :members:
    :undoc-members:
    :show-inheritance:


ethoscope.trackers.adaptive_bg_tracker module
---------------------------------------------

.. automodule:: ethoscope.trackers.adaptive_bg_tracker
    :members:
    :undoc-members:
    :show-inheritance:


