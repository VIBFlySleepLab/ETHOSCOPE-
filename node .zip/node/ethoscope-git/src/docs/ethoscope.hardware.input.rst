ethoscope.hardware.input package
================================

Submodules
----------

ethoscope.hardware.input.cameras module
---------------------------------------

.. automodule:: ethoscope.hardware.input.cameras
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ethoscope.hardware.input
    :members:
    :undoc-members:
    :show-inheritance:
