ethoscope.hardware.interfaces package
=====================================

Submodules
----------


ethoscope.hardware.interfaces.interfaces module
-----------------------------------------------

.. automodule:: ethoscope.hardware.interfaces.interfaces
    :members:
    :undoc-members:
    :show-inheritance:

ethoscope.hardware.interfaces.sleep_depriver_interface module
-------------------------------------------------------------

.. automodule:: ethoscope.hardware.interfaces.sleep_depriver_interface
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: ethoscope.hardware.interfaces
    :members:
    :undoc-members:
    :show-inheritance:
