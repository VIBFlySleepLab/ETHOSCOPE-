.. ethoscope documentation master file, created by
   sphinx-quickstart on Tue Sep  8 14:36:39 2015.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to ethoscope's documentation!
=====================================

Module contents
---------------

.. automodule:: ethoscope
    :members:
    :undoc-members:
    :show-inheritance:



Submodules
----------
.. toctree::

    ethoscope.core
    ethoscope.roi_builders
    ethoscope.trackers
    ethoscope.stimulators
    ethoscope.drawers




Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`




