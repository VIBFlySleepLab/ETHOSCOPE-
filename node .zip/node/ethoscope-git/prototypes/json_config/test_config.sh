#!/usr/bin/env bash

python device_server.py -g  /home/quentin/comput/ethoscope-git/ -r -i /data/psv_misc/monitor_validation/monitor_validation_raw.mp4  -d -j ../../prototypes/json_config/config.json

