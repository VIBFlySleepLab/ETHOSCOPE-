The router used is **TP-LINK MR3020**. 


We use `192.169.123.*` instead of the classic `192.168.0.*`, so one can change config at http://192.169.123.254/.

To load this config, go in "System Tools" and then in "Backup & Restore"

**Important point**, for setting a new platform, one needs to reserve `192.169.123.1` to the node. 
This requires manual intervention in so far as each node has a different MAC address.
 
 